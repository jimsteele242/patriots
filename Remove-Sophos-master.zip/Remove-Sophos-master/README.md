# Remove-Sophos
This is a powershell script used to uninstall sophos. 

You need to run the script as as Administrator and Sopshos Tamper Protection must be disabled which you can do programatically from the central console.
